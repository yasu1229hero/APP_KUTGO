How I build the chatbot?

Because the data is not enough to traing well with tensorflow, I gave up the previous code and just use a Google Framework to build it. So it is a very simple import job without the code. However for chatbot in the project, the completion rate is over 90%. 

How to use the chatbot's data?

1.Create a DialogFlow Account and create a project.

2.Import all data.

3.Save all intents and then the agent will be trained.

4.In order to display a richer responses such as image or website, don't use DialogFlow web demo function. So next step.

5.<script 
    defer="true" type="text/javascript" 
    botId="5d40790530c7e1243fb78ce2" 
    class="botcopy-embedder-d7lcfheammjct" 
    id="botcopy-embedder-d7lcfheammjct"> 
    var s = document.createElement('script'); 
    s.type = 'text/javascript'; s.async = true; 
    s.src = 'https://d7lcfheammjct.cloudfront.net/js/injection.js'; 
    var embedder = document.getElementById('botcopy-embedder-d7lcfheammjct'); 
    embedder.parentNode.insertBefore(s, embedder); 
</script>

6.Copy the script. Then, place it in the <head> of your html document or in the <body> of the page you want the bot to render on.

7.Test��open your website, the chatbot will appear in the bottom right corner of the webpage.

8.Ask it some question.


